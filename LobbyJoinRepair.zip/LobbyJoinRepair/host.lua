local function report(msg)
    log("[Lobby Join Repair] " .. tostring(msg))
end

local function refresh(session)
    if not managers.network or managers.network:session() ~= session then return end
    local mm = managers.network.matchmake
    if not mm or not mm.lobby_handler or not mm._lobby_attributes then return end
    if not mm.is_server_joinable or not mm:is_server_joinable() then return end
    local count = 1
    for _ in pairs(session:peers()) do count = count + 1 end
    if count >= (tweak_data.max_players or 4) then return end
    if not mm.server_state_name or mm:server_state_name() ~= "in_lobby" then return end
    if mm.set_num_players and mm.set_server_joinable then
        mm:set_num_players(count)
        mm:set_server_joinable(true)
        report("Refreshed open lobby; players=" .. count)
    end
end

local function schedule(session)
    for _, delay in ipairs({2, 6}) do
        DelayedCalls:Add("LobbyJoinRepair_" .. delay, delay, function()
            local ok, err = pcall(refresh, session)
            if not ok then report(err) end
        end)
    end
end

local function hook(method, callback)
    if type(HostNetworkSession[method]) == "function" then
        Hooks:PostHook(HostNetworkSession, method, "LobbyJoinRepair_" .. method, callback)
    end
end

hook("add_peer", function(self)
    report("Peer added")
    schedule(self)
end)
hook("on_peer_entered_lobby", function(self)
    report("Peer entered lobby")
    schedule(self)
end)
hook("on_join_request_received", function(self)
    report("Join request processed")
end)
hook("on_peer_connection_established", function(self, peer, other_id)
    report("Peer connection event; target slot=" .. tostring(other_id))
end)
hook("remove_peer", function(self)
    report("Peer removed")
    schedule(self)
end)
report("Host hooks loaded")
